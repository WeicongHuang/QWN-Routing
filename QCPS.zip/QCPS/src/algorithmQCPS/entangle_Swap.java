package algorithmQCPS;

import java.util.HashMap;
import java.util.Random;
import java.util.Stack;
import java.util.Map.Entry;

import topoQCPS.node;

public class entangle_Swap {
	static HashMap<Integer, Stack<node>> link_success_path = new HashMap<Integer, Stack<node>>();// store all <id ,path > of final success requests
	static Stack<Integer> final_fail_path_idSet = new Stack<Integer>(); // store all failed path ids
	static Stack<Integer> tempory_failID;//  store path id due to failed entanglement
	static HashMap<Integer, Stack<node>> entagle_direct = new HashMap<Integer, Stack<node>>();
	static Stack<Integer> tempory_direct_failID;
	public static HashMap<Integer, Integer> num_success_direct_request;
	
	public static int try_directentangle(double entangle_cre_succes) {
		tempory_direct_failID = new Stack<Integer>();
		num_success_direct_request = new HashMap<Integer, Integer>();
		entagle_direct = MajorPath.r;
		for (Entry<Integer, Stack<node>> entry : entagle_direct.entrySet()) {
			Stack<Boolean> Path_directentangle_state = new Stack<Boolean>();
			int path_node_size = entry.getValue().size();// node size of each request
			int min_link_num = 999;
			if (path_node_size == 2) {
				min_link_num = entry.getValue().get(0).neighbour.get(entry.getValue().get(1)).getRealWidth();
				num_success_direct_request.put(entry.getKey(), min_link_num);
			} else {				
			for (int i = 0; i < path_node_size - 2; i++) {
				boolean entangle_status = false;
				int pre_path_width = entry.getValue().get(i).neighbour.get(entry.getValue().get(i + 1))
						.getRealWidth();
				int next_path_width = entry.getValue().get(i + 1).neighbour.get(entry.getValue().get(i + 2))
						.getRealWidth();
				int real_path_width = pre_path_width > next_path_width ? next_path_width : pre_path_width;
				int tempory_num_linknum = 0;
				for (int k = 0; k < real_path_width; k++) { // according to the width of path
					Random random = new Random();
					int g = random.nextInt(10);
					if (g >= 0 && g < 10 * entangle_cre_succes) {
						entangle_status = true;
						tempory_num_linknum++;
					}
				}//相邻节点之间进行纠缠的次数是link少的那个
				Path_directentangle_state.add(entangle_status);
				if (tempory_num_linknum < min_link_num) {// the number of successful entanglements on this road
					min_link_num = tempory_num_linknum;
					}
				}
			}
			if (Path_directentangle_state.contains(false)) {
				tempory_direct_failID.add(entry.getKey());//Store the key of the failed node
			} else {
				num_success_direct_request.put(entry.getKey(), min_link_num);// Put the number of requests and successful links
			}
		}
		for (Integer i : tempory_direct_failID) {
			entagle_direct.remove(i);//Remove entanglement failed link
		}
		int sum = 0;
		for (Entry<Integer, Integer> entry : num_success_direct_request.entrySet()) {//traversed successful requests
			sum += entry.getValue();
		}
		return sum;
	}


}
