package topo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class node {
	int nodeId;
	int x; 
	int y; 
	List<Integer> request = new ArrayList<Integer>(); //request list 
	public HashMap<node, link> neighbour = new HashMap<node, link>(); //neighbor

	public node(int nodeId, int x, int y) {
		this.nodeId = nodeId;
		this.x = x;
		this.y = y;
	}

	public List<Integer> getRequest() {
		return request;
	}

	public void setRequest(List<Integer> request) {
		this.request = request;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}


	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}

}
