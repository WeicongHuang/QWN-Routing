package topoQCPS;

public class link {
	int linkID;
	int width;
	int use_times;
	double success_rate;
	boolean create_success;
	int realWidth=0;
	public boolean isCreate_success() {
		return create_success;
	}

	public void setCreate_success(boolean create_success) {
		this.create_success = create_success;
	}

	public link(int linkID, int width,  double success_rate,boolean create_success) {
		this.linkID = linkID;
		this.width = width;
		this.use_times= 0;
		this.success_rate = success_rate;
		this.create_success = false;
		this.create_success=create_success;
	}

	public int getLinkID() {
		return linkID;
	}

	public void setLinkID(int linkID) {
		this.linkID = linkID;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}
	public int getRealWidth() {
		return realWidth;
	}

	public void setRealWidth(int realWidth) {
		this.realWidth = realWidth;
	}
	public int getUse_times() {
		return use_times;
	}

	public void setUse_times_plus() {
		++this.use_times;
	}
	public void setUse_times_minus() {
		--this.use_times;
	}

	public double getSuccess_rate() {
		return success_rate;
	}

	public void setSuccess_rate(double success_rate) {
		this.success_rate = success_rate;
	}

}
