package algorithmQCPS;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Map.Entry;
import topoQCPS.link;
import topoQCPS.node;

public class FunctionFindPath {
	public static double energy_tx = 50*Math.pow(10, -6);// 50 uJ
	public static double energy_rx = 10*Math.pow(10, -6);// 10 uJ
	public static boolean constructPath(Stack<node> nodePath,node source, node des, int request_id) {
		node current = source;
		node next_node = null;
		int size = nodePath.size();
		if (source == null && (size == 0 || size == 1)) {
			return false;
		} else if (source == null && size > 1) {// block node
			node unused = nodePath.pop();
			node peek = nodePath.peek();
			nodePath.pop();
			peek.neighbour.get(unused).setUse_times_minus();
			return constructPath(nodePath,peek, des, request_id);
		} else {
			current.consume_energy(energy_tx);
			nodePath.push(current);
			if (current.neighbour.containsKey(des) &&current.neighbour.get(des).isCreate_success()) {
				current.neighbour.get(des).setUse_times_plus();
				des.getRequest().add(request_id);
				nodePath.push(des);		
				des.consume_energy(energy_rx);
				return true;			
			} else {
				// choose optimal neighbor node
				double curr_des_distance= CalDis.distanceCal(des,current);	
				next_node = compare_metric(current,current.neighbour, request_id,  des, curr_des_distance);
				if (next_node != null) {
					next_node.neighbour.get(current).setUse_times_plus();
				}
				current = next_node;
				return constructPath(nodePath,current, des, request_id);
			}
		}
	}

	public static boolean TestNoconflict(Stack<node> nodePath) {
		int length=nodePath.size();
		for(int i=length-1;i>0;i--) {			
			node nodepre=nodePath.elementAt(i);
			node nodenext=nodePath.elementAt(i-1);
			if(nodepre.neighbour.get(nodenext).getUse_times()>1) {
				return false;
			}
		}		
		return true;
	}
	
	public static node compare_metric(node current,HashMap<node, link> neighbour, int request_id, node des, double curr_des_distance) {
		int width = 0;
		List<Double> metric=new ArrayList<Double>();
		HashMap<node, List<Double>> next_neighbour = new HashMap<node, List<Double>>();
		Set<Map.Entry<node, link>> entrySet = neighbour.entrySet();
		for (Map.Entry<node, link> entry : entrySet) {
			entry.getKey().consume_energy(energy_rx);
			if ( entry.getKey().getRequest().contains(request_id)) {
				continue;
			}
			
			width = entry.getValue().getWidth();
			metric=new ArrayList<Double>();
			metric.add(1-(CalDis.distanceCal(entry.getKey(),des)/curr_des_distance));
			metric.add((double) width);
			next_neighbour.put(entry.getKey(), metric);
		}
		if (next_neighbour.size() > 0) {
			
			List<Map.Entry<node, List<Double>>> list = new ArrayList<Map.Entry<node, List<Double>>>(next_neighbour.entrySet());
			Collections.sort(list, new Comparator<Map.Entry<node, List<Double>>>() {
				@Override
				public int compare(Entry<node, List<Double>> o1, Entry<node, List<Double>> o2) {
					int i=o2.getValue().get(0).compareTo(o1.getValue().get(0));
					if (i==0) {
						int j=o2.getValue().get(1).compareTo(o1.getValue().get(1));
						return j;
					}
					return i;
				}
			});
			int index = -1;
			for (int i = 0; i < list.size(); i++) {
				if (num_neighbour(list.get(i).getKey(), request_id) > 0 && list.get(i).getKey().neighbour.get(current).isCreate_success()) {
					index = i;
					break;
				}
			}
			if (index == -1) {
				return null;
			}
			list.get(index).getKey().getRequest().add(request_id);
			return list.get(index).getKey();	
		} else {
			return null;
		}
	}
	
	public static int num_neighbour(node n, int id) {
		if (n == null) {
			return 0;
		}
		int i = 0;
		for (Map.Entry<node, link> entry :  n.neighbour.entrySet()) {
			if (entry.getValue().isCreate_success()&& !entry.getKey().getRequest().contains(id)) {
				i++;
			}
		}
		return i;
	}
	
	public static void pathBack(Stack<node> nodePath,int requestid) {
		// TODO Auto-generated method stub
		int i = 0;
		int endindex;
		int startindex;
		while (nodePath.size() > 2 && i < nodePath.size() - 2) {
			++i;
			node top = nodePath.get(nodePath.size() - i);
			top.consume_energy(energy_tx);
			startindex = -1;
			for (int k = 0; k < (nodePath.size() - 1 - i); k++) {
				if (top.neighbour.containsKey(nodePath.get(k))&&top.neighbour.get(nodePath.get(k)).isCreate_success()) {
					startindex = k;
					nodePath.get(k).consume_energy(energy_rx);
					break;
				}
			}
			
			endindex = nodePath.size() - i;
			if (startindex != -1) {
				for (int j = startindex; j < endindex; j++) {
					// delete intermediate nodes and relative relationship
					node pre = nodePath.get(j);
					node back = nodePath.get(j + 1);
					pre.neighbour.get(back).setUse_times_minus(); //set the state of unused link to false
					back.neighbour.get(pre).setUse_times_minus();
					back.getRequest().remove( Integer.valueOf(requestid));
				}
				node start = nodePath.get(startindex);
				node end = nodePath.get(endindex);
				start.neighbour.get(end).setUse_times_plus();
				end.neighbour.get(start).setUse_times_plus();
				nodePath.get(endindex).getRequest().add(requestid);
				for (int j = endindex - 1; j > startindex; j--) {
					 nodePath.remove(j);
				}
			}
		}
	}
}
