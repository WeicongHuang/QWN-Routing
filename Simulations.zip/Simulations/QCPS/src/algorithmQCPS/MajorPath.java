package algorithmQCPS;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Stack;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import topoQCPS.link;
import topoQCPS.node;
public class MajorPath {
	public static double energy_distribute=1*Math.pow(10, -3);//1mJ
	public static ArrayList<node> nodeList ; //store node in network
	static double time_slot=1.5*Math.pow(10,-6);//L=200
	static double light_speed=3*Math.pow(10, 8);
	static Stack<node> nodePath;
	static HashMap<Integer, Stack<node>> r;
	static ArrayList<Stack<node>> result;
	static HashMap<Integer,Stack<Integer>> request_restore;
	public static boolean findPath( int requestNum) throws BiffException, IOException, RowsExceededException, WriteException {
	// TODO Auto-generated method stub
		request_restore=new HashMap<Integer,Stack<Integer>> ();
		result = new ArrayList<Stack<node>>();
		r = new HashMap<Integer, Stack<node>>();
		int nodeNum=nodeList.size();
		if (nodeNum*(nodeNum-1)<requestNum*2) {return true;}
		for (int i = 0; i < requestNum; i++) {//construction for requests
			nodePath = new Stack<node>();
			node source = nodeList.get((int) (1 + Math.random() * nodeNum/2));
			node des = nodeList.get((int) (nodeNum/2 + Math.random() * nodeNum/2));
			int requestid = i;
			Stack<Integer> nodeid=new Stack<Integer>();
			nodeid.add(source.getNodeId());
			nodeid.add(des.getNodeId());
			request_restore.put(requestid, nodeid);
			source.getRequest().add(requestid);
			if (FunctionFindPath.constructPath(nodePath,source, des, requestid)) {
				FunctionFindPath.pathBack(nodePath,requestid);			
				if(FunctionFindPath.TestNoconflict(nodePath)) {
				result.add(nodePath);	
				r.put(requestid, nodePath);
			}
			}
		}
		return false;
	}
		
	public static void constructNode(String Path) throws BiffException, IOException {
		nodeList=new ArrayList<node>();
		InputStream file = new FileInputStream(Path);
		Workbook rwb = Workbook.getWorkbook(file);
		Sheet oFirstSheet = rwb.getSheet(0);
		int rows = oFirstSheet.getRows();
		int nodeId;
		int x;
		int y;
		for (int i = 1; i < rows; i++) {//first line in the table is title
			nodeId = Integer.parseInt(oFirstSheet.getCell(0, i).getContents());
			x = Integer.parseInt(oFirstSheet.getCell(1, i).getContents());
			y = Integer.parseInt(oFirstSheet.getCell(2, i).getContents());
			node n = new node(nodeId, x, y);
			nodeList.add(n);
		}
	}
	
	public static void isEnergyLow() { 
		 ArrayList<node> delete=new ArrayList<node>();
		for(int i=0;i<nodeList.size();i++) {
			if( !nodeList.get(i).isLowMinEnergy()) {
			delete.add(nodeList.get(i));				
			} 
		}
			for(node m:delete) {
				nodeList.remove(m);
			}
	}
	
	public static void initialReqNeigh() {//start next round and parameters are reset 
		for(node n :nodeList) {
			n.setNeighbor();
			n.setRequest();
		}
	}
	
	
	//Add neighbor nodes and links between each node after traversal
		public static void addNeighbour(double link_creat_success) {
			node current_node;
			node neighbour_node;
			int linkID = 0;
			int width;		
			for (int i = 0; i < nodeList.size() - 1; i++) {
				current_node = nodeList.get(i);
				for (int j = i + 1; j < nodeList.size(); j++) {
					neighbour_node = nodeList.get(j);
					double distance =CalDis.distanceCal(neighbour_node ,current_node);
					if (distance < 200) {//max distance is set to 200
						width = (int) (time_slot*light_speed/distance);//modified											
						link l = new link(++linkID, width, link_creat_success,false);
						int success_width =0;
						int min_linkwidth=999;
						for(int k=0; k<width;k++) {
							current_node.consume_energy(energy_distribute);
							Random random = new Random();
							int g = random.nextInt(10);
							if(g>=0&&g<10*link_creat_success) {
								l.setCreate_success(true);
								success_width++;
							}
						}								
						if((success_width>0)&&(success_width<min_linkwidth)) {
							l.setRealWidth(success_width);
							current_node.neighbour.put(neighbour_node, l);
							neighbour_node.neighbour.put(current_node, l);	
						}										
					}
				}
			}
		}
}