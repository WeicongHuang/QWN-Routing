package runQCPS;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import algorithmQCPS.MajorPath;
import algorithmQCPS.entangle_Swap;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import topoQCPS.node;

public class Simulations {
	static int row=0;
	static double loop_time=1000;
	static double time_slot=1.5*Math.pow(10,-6);
	static double light_speed=3*Math.pow(10, 8);
	static double [] link_creat_success= {0.6,0.7,0.8,0.9,1};// default link_creat_success[2]
	static int [] request_num= {2,4,6,8,10};//default request_num[3]
	static int [] node_num= {100,150,200,250,300};//default node_num 200
	static double[] entangle_create_success= { 0.6,0.7,0.8,0.9,1};//default entangle_create_success[3]
	static String[] pathSet= {"D:\\ECLIPSE\\workspace\\QCPS\\example\\nodeSet-100.xls","D:\\ECLIPSE\\workspace\\QCPS\\example\\nodeSet-150.xls","D:\\ECLIPSE\\workspace\\QCPS\\example\\nodeSet-200.xls","D:\\ECLIPSE\\workspace\\QCPS\\example\\nodeSet-250.xls","D:\\ECLIPSE\\workspace\\QCPS\\example\\nodeSet-300.xls"};
	static ArrayList<node> nodeList ;
	static int[] timeSlots= {1000,2000,3000,4000,5000};
	public static void main(String[] args) throws RowsExceededException, BiffException, WriteException, IOException {
		// TODO Auto-generated method stub
		WritableWorkbook writeBook = Workbook.createWorkbook(new File("D:\\ECLIPSE\\workspace\\QCPS\\example\\QCPS-Performance.xls"));
		WritableSheet firstSheet = writeBook.createSheet("result", 1);
		firstSheet.addCell(new Label(0, row, String.valueOf("condition")));
		firstSheet.addCell(new Label(1, row, String.valueOf("thoughout")));
		firstSheet.addCell(new Label(2, row, String.valueOf("correct rate")));
		firstSheet.addCell(new Label(3, row, String.valueOf("average energy ")));
		firstSheet.addCell(new Label(4, row, String.valueOf("number of nodes")));
		
		row++;
		for(int i=0;i<timeSlots.length;i++) {
			reference(timeSlots[i],firstSheet);
		}
		
		linkCreatPerformance(firstSheet);
		entangleCreatePerformance(firstSheet);
		requestNumPerformance(firstSheet); 
		nodeNumPerformance(firstSheet);

		writeBook.write();
		writeBook.close();
		System.out.println();
	}
	
	public static void reference(int times,WritableSheet firstSheet) throws RowsExceededException, BiffException, WriteException, IOException {
		/*next-node_num	 */		
		firstSheet.addCell(new Label(0, row, String.valueOf("reference: "+ "number of time slots"+ times)));
		double run_eps_sum=0;	
		double size_direct_request=0;
		MajorPath.constructNode(pathSet[2]);
		int i =0;
		for(;i<times;i++) {
			MajorPath.isEnergyLow();
			MajorPath.initialReqNeigh();
			MajorPath.addNeighbour(link_creat_success[2]); 
			if(MajorPath.findPath(request_num[3])) {
				break;
			};
			run_eps_sum+=entangle_Swap.try_directentangle(entangle_create_success[3]);
			size_direct_request+= entangle_Swap.num_success_direct_request.size();
			}
		double correctrate=(size_direct_request/i)/request_num[3];	
		firstSheet.addCell(new Label(1, row, String.valueOf(run_eps_sum/i)));
		firstSheet.addCell(new Label(2, row, String.valueOf(correctrate)));
		double n_energy=0;
		for(node n:MajorPath.nodeList) {
			n_energy+=n.getResidual_energy();
		}
		firstSheet.addCell(new Label(3, row, String.valueOf(n_energy/200)));
		firstSheet.addCell(new Label(4, row, String.valueOf(MajorPath.nodeList.size())));
		row++;
		System.out.println("reference correct rate: "+correctrate+ " thoughout: "+run_eps_sum/i);
		System.out.println("residual energy " + n_energy/200+" number of node  "+MajorPath.nodeList.size());
	}
		
	public static void 	linkCreatPerformance(WritableSheet firstSheet) throws RowsExceededException, BiffException, WriteException, IOException {
		/*next --node_num	 */			
		for(int j=0;j<link_creat_success.length;j++) {
			firstSheet.addCell(new Label(0, row, String.valueOf("link_creat_success: "+link_creat_success[j])));
			double run_eps_sum=0;	
			double size_direct_request=0;
			MajorPath.constructNode(pathSet[2]);
			int i =0;
			for(;i<loop_time;i++) {
				MajorPath.isEnergyLow();
				MajorPath.initialReqNeigh();
				MajorPath.addNeighbour(link_creat_success[j]); 
				if(MajorPath.findPath(request_num[3])) {
					break;
				};
				run_eps_sum+=entangle_Swap.try_directentangle(entangle_create_success[3]);
				size_direct_request+= entangle_Swap.num_success_direct_request.size();
				}
			double correctrate=(size_direct_request/i)/request_num[3];	
			firstSheet.addCell(new Label(1, row, String.valueOf(run_eps_sum/i)));
			firstSheet.addCell(new Label(2, row, String.valueOf(correctrate)));
			row++;
			System.out.println("link_creat_success: "+link_creat_success[j]+"correct rate: "+correctrate+ " thoughout: "+run_eps_sum/i);
		}		
		System.out.println();
	}
	
	public static void requestNumPerformance(WritableSheet firstSheet) throws RowsExceededException, BiffException, WriteException, IOException {/*next 锟斤拷锟斤拷reference锟斤拷锟叫革拷锟侥斤拷锟斤拷实锟斤拷--node_num	 */		
		for(int j=0;j<request_num.length;j++) {
			double size_direct_request=0;
			double run_eps_sum=0;	
			firstSheet.addCell(new Label(0, row, String.valueOf("request_num: "+request_num[j])));
			MajorPath.constructNode(pathSet[2]);
			int i =0;
			for(;i<loop_time;i++) {
				MajorPath.isEnergyLow();
				MajorPath.initialReqNeigh();
				MajorPath.addNeighbour(link_creat_success[2]); 
				if(MajorPath.findPath(request_num[j])) {
					break;
				};
				run_eps_sum+= entangle_Swap.try_directentangle(entangle_create_success[3]);
     			size_direct_request+=  entangle_Swap.num_success_direct_request.size();
				}
			double correctrate=(size_direct_request/i)/request_num[j];	
			firstSheet.addCell(new Label(1, row, String.valueOf(run_eps_sum/i)));
			firstSheet.addCell(new Label(2, row, String.valueOf(correctrate)));
			row++;
			System.out.println("request_num: "+request_num[j]+" correct rate: "+correctrate+ " thoughout: "+run_eps_sum/i);
		}	
		System.out.println();
	}
	
	public static void entangleCreatePerformance(WritableSheet firstSheet) throws RowsExceededException, WriteException, IOException, BiffException {
		for(int j=0;j<entangle_create_success.length;j++) {
			double size_direct_request=0;
			double run_eps_sum=0;	
			firstSheet.addCell(new Label(0, row, String.valueOf("entangle_create_success: "+entangle_create_success[j])));
			MajorPath.constructNode(pathSet[2]);
			int i =0;
			for(;i<loop_time;i++) {
				MajorPath.isEnergyLow();
				MajorPath.initialReqNeigh();
				MajorPath.addNeighbour(link_creat_success[2]); 
				if(MajorPath.findPath(request_num[3])) {
					break;
				};		
				run_eps_sum+=entangle_Swap.try_directentangle(entangle_create_success[j]);
				size_direct_request+=  entangle_Swap.num_success_direct_request.size();
				}
			double correctrate=(size_direct_request/i)/request_num[3];	
			firstSheet.addCell(new Label(1, row, String.valueOf(run_eps_sum/i)));
			firstSheet.addCell(new Label(2, row, String.valueOf(correctrate)));
			row++;
			System.out.println("entangle_create_success: "+entangle_create_success[j]+" correct rate: "+correctrate+ " thoughout: "+run_eps_sum/i);
			}				
		System.out.println();
		}	
	
	public static void nodeNumPerformance(WritableSheet firstSheet) throws RowsExceededException, WriteException, IOException, BiffException {
		for(int j=0;j<node_num.length;j++) {
			double size_direct_request=0;
			double run_eps_sum=0;	
			firstSheet.addCell(new Label(0, row, String.valueOf("node num: "+node_num[j])));
			MajorPath.constructNode(pathSet[j]);
			int i =0;
			for(;i<loop_time;i++) {
				MajorPath.isEnergyLow();
				MajorPath.initialReqNeigh();
				MajorPath.addNeighbour(link_creat_success[2]); 
				if(MajorPath.findPath(request_num[3])) {
					break;
				};		
				run_eps_sum+=entangle_Swap.try_directentangle(entangle_create_success[3]);
				size_direct_request+=  entangle_Swap.num_success_direct_request.size();
				}
			double correctrate=(size_direct_request/i)/request_num[3];	
			firstSheet.addCell(new Label(1, row, String.valueOf(run_eps_sum/i)));
			firstSheet.addCell(new Label(2, row, String.valueOf(correctrate)));
			row++;
			System.out.println("node num: "+node_num[j]+" correct rate: "+correctrate+ " thoughout: "+run_eps_sum/i);
			}				
		System.out.println();
		}	
		
}