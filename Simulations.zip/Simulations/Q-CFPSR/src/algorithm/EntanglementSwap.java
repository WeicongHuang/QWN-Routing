package algorithm;
import java.util.HashMap;
import java.util.Random;
import java.util.Stack;
import java.util.Map.Entry;
import topo.node;

public class EntanglementSwap {
	public static double energy_swap=1*Math.pow(10, -3);  //ES Energy =1 mJ
	static HashMap<Integer, Stack<Integer>> all_request_inforamtion = new HashMap<Integer, Stack<Integer>>();
	static HashMap<Integer, Stack<node>> link_success_path = new HashMap<Integer, Stack<node>>();// store final success requests in format<id,path > 
	static Stack<Integer> final_fail_path_idSet = new Stack<Integer>(); //Store the final failed paths
	static Stack<Integer> tempory_failID; // Store paths with failed entanglement swapping
	public static HashMap<Integer, Integer> num_success_request;
	
	public static int try_entangle(double entangle_cre_succes) {
		all_request_inforamtion = MajorPath.request_restore;
		link_success_path = repairPath.all_result;
		final_fail_path_idSet = repairPath.fail_repair_path;
		tempory_failID = new Stack<Integer>();
		num_success_request = new HashMap<Integer, Integer>();
		for (Entry<Integer, Stack<node>> entry : link_success_path.entrySet()) {
			Stack<Boolean> Path_entangle_state = new Stack<Boolean>();
			int path_node_size = entry.getValue().size();
			int min_link_num = 999;
			if (path_node_size == 2) {
				min_link_num = entry.getValue().get(0).neighbour.get(entry.getValue().get(1)).getRealWidth();
				num_success_request.put(entry.getKey(), min_link_num);
			} else {
				for (int i = 0; i < path_node_size - 2; i++) {
					boolean entangle_status = false;
					int pre_path_width = entry.getValue().get(i).neighbour.get(entry.getValue().get(i + 1))
							.getRealWidth();
					int next_path_width = entry.getValue().get(i + 1).neighbour.get(entry.getValue().get(i + 2))
							.getRealWidth();
					int real_path_width = pre_path_width > next_path_width ? next_path_width : pre_path_width;
					int tempory_num_linknum = 0;
					for (int k = 0; k < real_path_width; k++) { 
						entry.getValue().get(i + 1).consume_energy(energy_swap);
						Random random = new Random();
						int g = random.nextInt(10);
						if (g >= 0 && g < 10 * entangle_cre_succes) {
							entangle_status = true;
							tempory_num_linknum++;
						}
					}
					Path_entangle_state.add(entangle_status);
					if (tempory_num_linknum < min_link_num) {
						min_link_num = tempory_num_linknum;
					}
				}
			}
			if (Path_entangle_state.contains(false)) {
				final_fail_path_idSet.add(entry.getKey());
				tempory_failID.add(entry.getKey());
			} else {
				num_success_request.put(entry.getKey(), min_link_num);
			}
		}
		remove_fail_finalPath();
		int sum = 0;
		for (Entry<Integer, Integer> entry : num_success_request.entrySet()) {
			sum += entry.getValue();
		}
		return sum;
	}
	public static void remove_fail_finalPath() {
		for (Integer i : tempory_failID) {
			link_success_path.remove(i);
		}
	}
}
