package algorithm;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import topo.link;
import topo.node;
public class MajorPath {
	static double time_slot=1.5*Math.pow(10,-6);//L=200 width=3
	static double light_speed=3*Math.pow(10, 8);
	public static ArrayList<node> nodeList ;
	static Stack<node> nodePath;
	static HashMap<Integer, Stack<node>> r;
	static ArrayList<Stack<node>> result;
	static HashMap<Integer,Stack<Integer>> request_restore;
	public static boolean findPath( double  link_success_rate,int requestNum,String FilePath) throws BiffException, IOException, RowsExceededException, WriteException {
		// TODO Auto-generated method stub
		request_restore=new HashMap<Integer,Stack<Integer>> ();
		isEnergyLow();
		initialReqNeigh();
		addNeighbour( link_success_rate);
		result = new ArrayList<Stack<node>>();
		r = new HashMap<Integer, Stack<node>>();
		int nodeNum=nodeList.size();
		if (nodeNum*(nodeNum-1)<requestNum*2) {return true;}
		for (int i = 0; i < requestNum; i++) {
			nodePath = new Stack<node>();
			node source = nodeList.get((int) (1 + Math.random() * nodeNum/2));
			node des = nodeList.get((int) (nodeNum/2 + Math.random() * nodeNum/2));
			int requestid = i;
			Stack<Integer> nodeid=new Stack<Integer>();
			nodeid.add(source.getNodeId());
			nodeid.add(des.getNodeId());
			request_restore.put(requestid, nodeid);
			
			source.getRequest().add(requestid);
			if (FunctionFindPath.constructPath(nodePath,source, des, requestid)) {
				FunctionFindPath.pathBack(nodePath,requestid);
				result.add(nodePath);
				r.put(requestid, nodePath);
			}
		}
		return false;
	}
	
//Read nodes from text and store in nodelist
	public static int constructNode(String Path) throws BiffException, IOException {
		nodeList = new ArrayList<>();
		InputStream file = new FileInputStream(Path);
		Workbook rwb = Workbook.getWorkbook(file);
		Sheet oFirstSheet = rwb.getSheet(0);
		int rows = oFirstSheet.getRows();
		int nodeId;
		int x;
		int y;
		for (int i = 1; i < rows; i++) {
			nodeId = Integer.parseInt(oFirstSheet.getCell(0, i).getContents());
			x = Integer.parseInt(oFirstSheet.getCell(1, i).getContents());
			y = Integer.parseInt(oFirstSheet.getCell(2, i).getContents());
			node n = new node(nodeId, x, y);
			nodeList.add(n);
		}
		return (rows-1);//first line is title
	}
	
//Add neighbor nodes and links between each node after traversal
	public static void addNeighbour(double link_success_rate) {
		node current_node;
		node neighbour_node;
		int linkID = 0;
		int width;
		boolean use_state;
		for (int i = 0; i < nodeList.size() - 1; i++) {
			current_node = nodeList.get(i);
			for (int j = i + 1; j < nodeList.size(); j++) {
				neighbour_node = nodeList.get(j);
				double distance =CalDis.distanceCal(neighbour_node ,current_node);
				if (distance < 200) {//max distance is set to 200
					width = (int) (time_slot*light_speed/distance);										
					use_state = false;
					link l = new link(++linkID, width, use_state, link_success_rate,false);
					current_node.neighbour.put(neighbour_node, l);
					neighbour_node.neighbour.put(current_node, l);
				}
			}
		}
	}
	
	public static void isEnergyLow() {
		 ArrayList<node> delete=new ArrayList<node>();
		for(int i=0;i<nodeList.size();i++) {
			if( !nodeList.get(i).isLowMinEnergy()) {
			delete.add(nodeList.get(i));				
			} 
		}
			for(node m:delete) {
				nodeList.remove(m);
				System.out.println("node exit");
			}
	}
	
	public static void initialReqNeigh() {
		for(node n :nodeList) {
			n.setNeighbor();
			n.setRequest();
		}
	}
}