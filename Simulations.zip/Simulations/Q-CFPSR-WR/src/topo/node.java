package topo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class node {
	int nodeId;
	int x; // node's x_position
	int y; // node's y_position
	double residual_energy; // node's residual energy
	List<Integer> request ;//request list 
	public HashMap<node, link> neighbour;//neighbor

	public node(int nodeId, int x, int y) {
		this.nodeId = nodeId;
		this.x = x;
		this.y = y;
		this.residual_energy = 60;//��ʼ���ڵ������Ϊ60J
	    this.request = new ArrayList<Integer>();
		this.neighbour = new HashMap<node, link>();
	}

	public List<Integer> getRequest() {
		return request;
	}

	public void setRequest(List<Integer> request) {
		this.request = request;
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public double getResidual_energy() {
		return residual_energy;// ���ؽڵ�Ĳ�������
	}

	public void consume_energy(double conEnergy) {
		this.residual_energy = this.residual_energy-conEnergy; //�ڵ���������
	}
	public boolean isLowMinEnergy() {	
		if(residual_energy>2) {
			return true;
		}else {
			return false;
			}
	}

	public int getNodeId() {
		return nodeId;
	}

	public void setNodeId(int nodeId) {
		this.nodeId = nodeId;
	}
	
	public void setRequest() {
		this.request = new ArrayList<Integer>();
	}
	
	public void setNeighbor() {
		this.neighbour = new HashMap<node, link>();
	}
	

}

